RIYADHPOLY - PHASE 1: DESIGN AND BOARD
Prince Sultan University | CS102 Computer Programming II | Term 261

GROUP
ALBANDARI ALSAIF 223511062
JOUDI ALHAZZANI 225410607
SARAH ALSHATHRI 224410428

FILES
RiyadhPoly_Phase1_Report.docx      Editable report with official university/college logos.
RiyadhPoly_Phase1_Report.pdf       Printable report.
Diagrams/RiyadhPoly_Phase1_UML.mmd  Detailed, editable Phase 1 UML class diagram.
Diagrams/RiyadhPoly_Whole_Project_Architecture.mmd  Whole-project planned architecture.
Diagrams/RiyadhPoly_Phase1_Overview.png  Condensed graphical overview.
Diagrams/RiyadhPoly_Phase1_Hierarchy.png  Readable Square and Ownable hierarchy.
Board_and_Test_Files/board.txt    Exact default sample board given in the handout.
Board_and_Test_Files/test_invalid_missing_field.txt
Board_and_Test_Files/test_invalid_unknown_group.txt
Board_and_Test_Files/test_invalid_nonnumeric_price.txt

HOW TO USE
1. Open the Word file to edit names, headings and documentation.
2. Open .mmd source in Mermaid Live Editor (https://mermaid.live/) or Mermaid-compatible software.
3. Make your Java classes match the final UML before the instructor check-in.
4. Load board.txt; confirm all 20 squares display correctly.
5. Load the three broken files; confirm clear line-specific error messages.
6. Confirm countOwned is zero for all five groups during Phase 1.

SCOPE
The package contains project documentation and example board files, not a compiled or runnable
Java application. Phase 2/3 classes in the whole-project diagram are future design, not
Phase 1 code. The Word report is based on the supplied Phase 1 specification and Overview.
