/** A checked exception for unreadable or malformed board files. */
public class InvalidBoardException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidBoardException(String message) {
        super(message);
    }

    public InvalidBoardException(int lineNumber, String reason) {
        super("line " + lineNumber + ": " + reason);
    }
}
