/** Empty Phase 1 stub. The game loop and money are added in Phase 2. */
public class Game {
}
