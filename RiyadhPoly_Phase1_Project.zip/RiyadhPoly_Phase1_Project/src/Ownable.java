/** A square which can be owned. A null owner means the bank owns it. */
public interface Ownable {
    int getPrice();
    int getBaseRent();
    String getGroup();
    Player getOwner();
    void setOwner(Player p);
}
