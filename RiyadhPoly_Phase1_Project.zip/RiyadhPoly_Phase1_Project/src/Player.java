/** Empty Phase 1 stub. Player state, Comparable and bots are added in Phase 2. */
public class Player {
}
